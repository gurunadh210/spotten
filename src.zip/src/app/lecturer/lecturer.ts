export interface Lecturer {
    id: number;
    fname: string;
    lname: string;
    email: string;
    phonenumber: number;
    gender: string;
    subject: string;
}