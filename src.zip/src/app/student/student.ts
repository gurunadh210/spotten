export interface Student {
    id: number;
    fname: string;
    lname: string;
    dob: Date;
    gender: string;
    email: string;
    phonenumber: number;
    guardianfname: string;
    guardianlname: string;
    guardianemail: string;
    guardianphoonenumber: number;
    address: string;
}